import random

#function to discard alll punctuation
def discard_punctuation(text):
    to_discard = '''!()-[]{};:'"\,<>./?@#$%^&;*_~'''
    for element in text:  
        if element in to_discard:  
            text = text.replace(element, '') 
    return text

#forming new file - 'new_dataset.txt' -  which won't have punctuation marks
with open('dataset_NB.txt','r') as f:
    data = f.read()
with open('new_dataset.txt','w+') as f2:
    f2.write(discard_punctuation(data.lower()))

#defining common words which will be removed from spam and non-spam training data later
common_words = ['i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', 'her', 'hers', 'herself', 'it', 'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', 'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', 'should', 'now']

#function to create a histogram of frequencies of words in spam and non-spam training data
def find_histograms(spam, non_spam):

    words_spam = []
    features = []

    #finding all words that occur in spam
    for email in spam:
        email_as_list = email.split()
        for word in email_as_list:
            words_spam.append(word) 
            features.append(word)

    #creating new list with only unique words
    unique_spam = list(dict.fromkeys(words_spam))

    #deleting all common words
    k=0
    while k<len(unique_spam):
        if unique_spam[k] in common_words:
            del(unique_spam[k])
        else: k+=1

    #creating a dictionary called hist_spam to store each unique word and it's frequencies 
    hist_spam={}
    for word in unique_spam:
        occurences = 0
        for email in spam:
            if word in email:
                occurences+=1
        hist_spam[word] = occurences

    #finding all words that occur in non-spam
    words_nonspam = []
    for email in non_spam:
        email_as_list = email.split()
        for word in email_as_list:
            words_nonspam.append(word)
            features.append(word)

    #creating new list with only unique words
    unique_nonspam = list(dict.fromkeys(words_nonspam))
    
    #deleting all common words
    k=0
    while k<len(unique_nonspam):
        if unique_nonspam[k] in common_words:
            del(unique_nonspam[k])
        else: k+=1

    #creating a dictionary called hist_non to store each unique word in non-spam and it's frequencies 
    hist_non = {}
    for word in unique_nonspam:
        occurences = 0
        for email in non_spam:
            if word in email:
                occurences+=1
        hist_non[word] = occurences
    
    #creating a list of all the unique words i.e features that may have occured in spam or non-spam
    unique_features = list(dict.fromkeys(features))

    #removing common words from unique_features
    k=0
    while k<len(unique_features):
        if unique_features[k] in common_words:
            del(unique_features[k])
        else: k+=1
    
    return hist_spam, hist_non, unique_features

  
def find_if_spam(email, i, total_spam, total_nonspam, unique_features):

    # By Bayes theorem : P(SPAM|W1,W2..,WN) is proportional to P(SPAM)*P(W1|SPAM)*P(W2|SPAM)..*P(WN|SPAM)
    # LAPLACE SMOOTHING (alpha = 1) : P(W|SPAM) = (number of spam emails with w + 1)/(number of spam emails + number of features)

    #finding P(SPAM)*P(W1|SPAM)*P(W2|SPAM)..*P(WN|SPAM)
    spam_prob = prob_spam
    for word in email:
        if word in hist_spam.keys():
            pr_w_given_spam = (hist_spam[word]+1)/(total_spam + len(unique_features))
        else:
            pr_w_given_spam = 1/(total_spam + len(unique_features))
        spam_prob = spam_prob * pr_w_given_spam
        
    # By Bayes theorem : P(NON-SPAM|W1,W2..,WN) is proportional to P(NON-SPAM)*P(W1|NON-SPAM)*P(W2|NON-SPAM)..*P(WN|NON-SPAM)

    #finding P(NON-SPAM)*P(W1|NON-SPAM)*P(W2|NON-SPAM)..*P(WN|NON-SPAM)
    nonspam_prob = prob_nonspam
    for word in email:
        if word in hist_non.keys():
            pr_w_given_nonspam = (hist_non[word]+1)/(total_nonspam + len(unique_features))
        else:
            pr_w_given_nonspam = 1/(total_nonspam + len(unique_features))
        nonspam_prob = nonspam_prob * pr_w_given_nonspam
    
    #comparing the two to see which is greater
    if (spam_prob>=nonspam_prob): return 1
    else: return 0


#shuffling data
f2 = open('new_dataset.txt', 'r')
new_data = f2.readlines()
random.shuffle(new_data)

i=0
total_acc = 0
while i<7:
    print("\nFOLD ", i+1)

    #dividing emails into training and testing
    division = int(len(new_data)/7)
    incr = division*i
    test_data = new_data[incr:division+incr]
    train_data = new_data[division+incr:]
    train_data.extend(new_data[:incr])

    #dividing training data into training data spam and training data non-spam
    spam = []
    non_spam = []
    for line in train_data:
        if (line[-2]=='1'):
            spam.append(line[:-2].lower())
        else: 
            non_spam.append(line[:-2].lower())
    
    prob_spam = len(spam) / (len(spam)+(len(non_spam)))
    prob_nonspam = len(non_spam) / (len(spam)+(len(non_spam)))
    
    #hist_spam : dictionary representing histogram of frequencies of all words in spam training data
    #hist_non : dictionary representing histogram of frequencies of all words in non spam training data
    #unique_features : list of all words in the entire dataset
    hist_spam, hist_non, unique_features = find_histograms(spam, non_spam)
    tp=0
    tn=0
    fp=0
    fn=0

    #converting test data into a list of emails so each email can be passed easily to the finction find_if_spam
    test_data_as_list=[]
    for email in test_data:
        email_as_list = email.split()
        k=0
        while k<len(email_as_list):
            if email_as_list[k] in common_words:
                del(email_as_list[k])
            else: k+=1
        test_data_as_list.append(email_as_list)

    #passing each email in test data one by one to check if spam
    j=0
    while (j<len(test_data_as_list)):
        final_classification = find_if_spam(test_data_as_list[j][:-1], j, len(spam), len(non_spam), unique_features)
        if final_classification ==1:
            if test_data[j][-2]=='1': tp+=1     #true positive
            else: fp+=1                         #false positive
        else:
            if test_data[j][-2]=='1': fn+=1     #false negative
            else: tn+=1                         #true negative
        j+=1
        
    accuracy = (tp+tn)/(tp+tn+fp+fn)*100
    print('Percentage of emails correctly classified: ', accuracy)
    total_acc += accuracy
    i+=1

print("\nOVERALL ACCURACY FOR ALL 7 FOLDS IS ", total_acc/7)
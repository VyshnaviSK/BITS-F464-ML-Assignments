#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
import pandas as pd
import pickle
import matplotlib.pyplot as plt
import random
from numpy import *
import math
import pandas

data1=pd.read_csv("dataset_LR.csv")  #read and  the dataset given
#(data1)

X = data1.iloc[:, 0:4].values 
Y = data1.iloc[:, 4].values 

def sigmoid_fn(X):
    return 1./(1 + np.exp(-X))

def predict_fn(X, f , threshold = 0.5):
    z = sigmoid_fn(np.dot(X,f.T))
    return z>=threshold

def loss_fn(Y, f):
    m=Y.shape[0]
    return (-1/m)*(Y.T @ np.log(f) + (1 - Y).T @ np.log(1 - f))

def accuracy(Y, Y_predict):
  n = len(Y)
  count = 0
  for i in range(0,n):
    if(Y_predict[i] == Y[i]):
      count += 1
  ans = (count * 100)/n
  return ans

def gradient_descent(x,y,theta,learning_rate=0.01,iterations = 1000):
   
    m = len(y)
    costs=np.array([])  #initialising prev cost to 0
    #thetas = np.zeros((iterations,4))
    thetas=[]
    accuracies = []
    for it in range(iterations): 
        a = x_train@theta.T  
        b = sigmoid_fn(a)
        c = loss_fn(y_train, b)
        
        
        theta = theta - (learning_rate/m)*np.array((b-y_train).T@x)  #Updating theta value after every iteration using delw
        thetas.append(theta)      
        #costs[it]  = find_cost(theta,x,y) #Updating previous cost
        
        acc = accuracy(y, predict_fn(x,theta))
        accuracies.append(acc)
        cost=np.squeeze(c)
        costs=np.append(costs,cost)
        #print(c)
        #(costs)
    return theta, costs, thetas, accuracies

#Function to solve regression using stochastic gradient descent method
def stochastic_gradient_descent(x,y,theta,learning_rate=0.1,iterations=1000):

    m = len(y)
    costs = np.array([])
    accuracies = []
    for i in range(iterations):
        cost =0.0
        #for i in range(100):
        rand_ind = np.random.randint(0,m)
        X_i = x[rand_ind].reshape(1,x.shape[1])
        y_i = y[rand_ind].reshape(1,1)

        a = X_i@(theta.T)
        b = sigmoid_fn(a)
        c = loss_fn(y_i, b)
        theta = theta -(1/m)*learning_rate*((b - y_i).T@X_i)

        acc = accuracy(y, predict_fn(x,theta))
        accuracies.append(acc)

        cost=np.squeeze(c)
        costs=np.append(costs,cost)
    costs[i]  = cost/m 
    return theta, costs, accuracies

dataset = np.array(data1)

for i in range(10):
    

    np.random.shuffle(dataset) #shuffling to avoid bias
    size_train=int(dataset.shape[0]*0.7)  #Training data size 70% of total
    size_test=int(dataset.shape[0]-size_train) #Testing data size 30% of total
    x_train,x_test,y_train,y_test=dataset[:size_train,0:4],dataset[:size_test,0:4],dataset[:size_train,4:5],dataset[:size_test,4:5]   
#splitting into 70-30

    inttheta=np.random.rand(1,4)  #initialising theta to random values to pass
    n_iter=200
    lr=0.1              
    gdtheta, costs_gd, thetas, accuracies_gd = gradient_descent(x_train,y_train,inttheta,lr,n_iter)   #finding weights through GD     
    sgdtheta,costs_sgd, accuracies_sgd = stochastic_gradient_descent(x_train,y_train,inttheta,lr,n_iter) #finding weights through sgd

    
#if (i==0):
    if (i==0):
        i, ind=0,0
        print("\nGRADIENT DESCENT\n")
        while (ind<len(costs_gd)):
                   print("Iteration no.", i)
                   print("Error Value:", costs_gd[ind])
                   i+=50
                   ind+=50
        print('\nWeights obtained from GD:\n',gdtheta)
        print("\nSTOCHASTIC GRADIENT DESCENT\n")
        i, ind=0,0
        while (ind<len(costs_sgd)):
                   print("Iteration no.", i)
                   print("Error Value:", costs_sgd[ind])
                   i+=50
                   ind+=50
        print('\nWeights obtained from SGD:\n',sgdtheta)
        
        plt.plot(costs_gd, 'r', label='GD')
        #plt.plot(costs_sgd, 'b', label='SGD')
        plt.ylabel('Error')
        plt.xlabel('Iterations')
        plt.legend()
        plt.show()


        plt.plot(accuracies_gd, 'r', label='GD')
        #plt.plot(accuracies_sgd, 'b', label='SGD')
        plt.ylabel('Accuracy')
        plt.xlabel('Iterations')
        plt.legend()
        plt.show()
        
        
#Comparing GD and SGD for different values of learning rate
print("\nCOMPARING GD FOR DIFFERENT LR VALUES - see plot")
n_iter=1000
iter_sgd=1000
lr1=0.05
lr2=0.01
lr3=0.1
theta_gd,costs,thetas,accuracies_gd = gradient_descent(x_train,y_train,inttheta,lr1,n_iter)
plt.plot(accuracies_gd,'r',label='GD')
plt.ylabel('Accuracy')
plt.xlabel('Iterations')
plt.title('GD for Learning Rate 0.05')
plt.legend()
plt.show() 
theta_gd,costs,thetas,accuracies_gd = gradient_descent(x_train,y_train,inttheta,lr2,n_iter)
plt.plot(accuracies_gd,'r',label='GD')
plt.ylabel('Accuracy')
plt.xlabel('Iterations')
plt.title('GD for Learning Rate 0.01')
plt.legend()
plt.show() 
theta_gd,costs,thetas,accuracies_gd = gradient_descent(x_train,y_train,inttheta,lr3,n_iter)
plt.plot(accuracies_gd,'r',label='GD')
plt.ylabel('Accuracy')
plt.xlabel('Iterations')
plt.title('GD for Learning Rate 0.1')
plt.legend()
plt.show() 
#Comparing GD and SGD for different values of learning rate
print("\nCOMPARING GD FOR DIFFERENT LR VALUES - see plot")
lr = [0.1, 0.01, 0.001]
color=['r', 'b', 'g']
k=0
n_iter=1000
iter_sgd=1000
for i in lr:
        theta_gd,costs,thetas,accuracies_gd = gradient_descent(x_train,y_train,inttheta,i,n_iter)
        plt.plot(costs, color[k], label=i)
        k+=1
plt.ylabel('Loss')
plt.xlabel('Iterations')
plt.title('GD for Different Learning Rates')
plt.legend()
plt.show()

#Comparing GD and SGD for different values of learning rate
print("\nCOMPARING GD FOR DIFFERENT LR VALUES - see plot")
lr1 = [0.1, 0.01, 0.05]
color=['r', 'b', 'g']

k=0
n_iter=10000
iter_sgd=50000

for i in lr1:
        theta_gd,costs,thetas,accuracies_gd = gradient_descent(x_train,y_train,inttheta,i,n_iter)
        plt.plot(accuracies_gd, color[k], label=i)
        k+=1
plt.ylabel('Accuracy')
plt.xlabel('Iterations')
plt.title('GD for Different Learning Rates')
plt.legend()
plt.show()



def f_score(X, Y):
    f_score = (2 * X * Y) / (X + Y)
    return f_score

y_test = np.array(y_test)
Y_predict = predict_fn(x_test, theta_gd)

true_p, true_n, false_p, false_n = [0,0,0,0]

for i in range(len(y_test)):
    if(y_test[i] == 1):
        if (Y_predict[i] == 1):
            true_p += 1
        else:
            false_n += 1
    else:
        if(Y_predict[i] == 0):
            true_n += 1
        else:
            false_p += 1

(true_p, false_p, true_n, false_n)

precision = true_p / (true_p + false_p)
recall = true_p / (true_p + false_n)

print('F-score: ', f_score(precision, recall))
print('Accuracy(%): ', accuracy(y_test, Y_predict))
print('Recall', recall)
print('precision', precision)
                       

#print("\nCOMPARING SGD FOR DIFFERENT LR VALUES - see plot")
#k=0
#for i in lr1:
        #theta_gd,costs,accuracies_sgd = stochastic_gradient_descent(x_train,y_train,inttheta,i,iter_sgd)
        #plt.plot(costs, color[k], label=i)
        #k+=1
#plt.ylabel('Loss')
#plt.xlabel('Iterations')
#plt.title('SGD for Different Learning Rates')
#plt.legend()
#plt.show()


print("\nCOMPARING SGD FOR DIFFERENT LR VALUES - see plot")
k=0
for i in lr1:
        theta_gd,costs,accuracies_sgd = stochastic_gradient_descent(x_train,y_train,inttheta,i,iter_sgd)
        plt.plot(accuracies_sgd, color[k], label=i)
        k+=1
plt.ylabel('Accuracy')
plt.xlabel('Iterations')
plt.title('SGD for Different Learning Rates')
plt.legend()
plt.show()




def accuracy(Y, Y_predict):
  n = len(Y)
  count = 0
  for i in range(0,n):
    if(Y_predict[i] == Y[i]):
      count += 1
  ans = (count * 100)/n
  return ans

def f_score(X, Y):
    f_score = (2 * X * Y) / (X + Y)
    return f_score

y_test = np.array(y_test)
Y_predict = predict_fn(x_test, theta_gd)

true_p, true_n, false_p, false_n = [0,0,0,0]

for i in range(len(y_test)):
    if(y_test[i] == 1):
        if (Y_predict[i] == 1):
            true_p += 1
        else:
            false_n += 1
    else:
        if(Y_predict[i] == 0):
            true_n += 1
        else:
            false_p += 1

(true_p, false_p, true_n, false_n)

precision = true_p / (true_p + false_p)
recall = true_p / (true_p + false_n)

print('F-score: ', f_score(precision, recall))
print('Accuracy(%): ', accuracy(y_test, Y_predict))
print('Recall', recall)
print('precision', precision)


# In[ ]:




